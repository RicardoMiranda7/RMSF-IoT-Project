/*									tab:4
 * Copyright (c) 2005 The Regents of the University  of California.  
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the copyright holders nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/**
 * Java-side application for testing serial port communication.
 * 
 *
 * @author Phil Levis <pal@cs.berkeley.edu>
 * @date August 12 2005
 */

import java.io.IOException;
import net.tinyos.message.*;
import net.tinyos.packet.*;
import net.tinyos.util.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Timestamp;

class Node{
	public int ID;
	public int activated;
}

 class Client_socket {
	
	private Socket socket;

	public Client_socket(){
		try {
			String IP = "192.168.0.100";
			int PORT = 1901;
			this.socket = new Socket(IP,PORT);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void send_message(String message){
        /*Sends public key to the home*/
		DataOutputStream os;
		try {
			os = new DataOutputStream(this.socket.getOutputStream());
			os.writeBytes(message);
			os.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Can´t send the message");
			e.printStackTrace();
		}
	}
	public String receive_message(){
		String message = "";
		
		InputStreamReader inputStream;
		try {
			inputStream = new InputStreamReader(this.socket.getInputStream());
			BufferedReader input = new BufferedReader(inputStream);
			message = input.readLine();
			
			/*if(message.regionMatches(0, "UPTODATE", 0, 8)){
				System.out.println(message);
			}else{
			System.out.println("ALARM at " + message);
			}*/
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Can´t receive the message");
			e.printStackTrace();
		}
		
		return message;
	}
	

}
public class TestSerial implements MessageListener {

  private MoteIF moteIF;
  public int PANid;
  
  public TestSerial(MoteIF moteIF) {
    this.moteIF = moteIF;
    this.moteIF.registerListener(new TestSerialMsg(), this);
  }

  public void sendPackets() {
    int counter = 0;
    byte[] data = new byte[12];
    // Os 4 primeiros bytes sao para o counter e p/ node_id
    //Node_id
    data[2] = (byte)0;
    data[3] = (byte)0;
    
    data[4] = (byte)1;//Base Station
    data[8] = (byte)1;//Buzzer Off
    for(int i=5;i<11;i++){
		if(i!=8){
			data[i] = (byte)0; 	
		}
	}
    Node[] nodes = new Node[2];
    nodes[0] = new Node(); nodes[1] = new Node();
    TestSerialMsg payload = new TestSerialMsg(data,0,data.length);
    Scanner s1 = new Scanner(System.in);
    System.out.print("PANid: ");
    PANid =  s1.nextInt();
    System.out.println();
    
    Scanner s2 = new Scanner(System.in);
	// ---------------Request to PHP Server----------------------------------------
	System.out.println("Begining client...");
	Client_socket c2 = new Client_socket();
	c2.send_message("BASE REQSETS " + PANid +"\n");
	String message = c2.receive_message();
	System.out.println("PHP Answer: "+ message);
	String[] parts = message.split(" ");
	System.out.print("Node Initial State: ");
	// -----------------------------------------------------------------------------
	int j=0;
	for (int i=5;i<parts.length;i=i+2){
		nodes[j].activated = Integer.parseInt(parts[i]);
		System.out.print(nodes[j].activated + " ");
		

			data[2] = (byte)0;
			data[3] = (byte)(j+1);
			data[4] = (byte)1;
			data[5] = (byte)(Integer.parseInt(parts[2]));//Buzzer enabled
			data[6] = (byte)Integer.parseInt(parts[i]);
			data[7] = (byte)(Integer.parseInt(parts[3]));//Propagate Buzzer enabled
			data[8] = (byte)0;//Buzzer Off
			data[11] = (byte)0;//Shut Down
			payload.set_counter(counter);
			try {
				moteIF.send(0, payload);
				System.out.println(payload);
				counter++;
		    }
		    catch (IOException exception) {
		      System.err.println("Exception thrown when sending packets. Exiting.");
		      System.err.println(exception);
		    }
			j++;
		
	}
	System.out.println();
	



    
    
    
  int flag = 0;
    try {
      while (true) {
    	 flag=0;
		Scanner scanner = new Scanner(System.in);
		// ---------------Request to PHP Server----------------------------------------
		System.out.println("Begining client...");
		Client_socket c1 = new Client_socket();
		c1.send_message("BASE REQSETS " + PANid +"\n");
		message = c1.receive_message();
		System.out.println("PHP Answer: "+ message);
		parts = message.split(" ");
		System.out.println("Parts (Node): " + parts[5] + " " + parts[7]);
		// -----------------------------------------------------------------------------
		j=0;
		for (int i=5;i<parts.length;i=i+2){

			System.out.println("I: " + i);
				if(nodes[j].activated != Integer.parseInt(parts[i])){
					
					data[2] = (byte)0;
					data[3] = (byte)(j+1);
					data[4] = (byte)1;
					data[5] = (byte)(Integer.parseInt(parts[2]));//Buzzer enabled
					data[6] = (byte)Integer.parseInt(parts[i]);
					data[7] = (byte)(Integer.parseInt(parts[3]));//Propagate Buzzer enabled
					data[8] = (byte)0;//Buzzer Off
					data[11] = (byte)0;//Shut Down
					nodes[j].activated = Integer.parseInt(parts[i]);
					flag = 1;
				
			}j++;
		}
		System.out.print("Enter node configs in format: <node_id> <buzzer_off>: ");
		
		// Generic packet
		if(flag!=1){
		
			// get the age as an int
			data[2] = (byte)0;
			data[3] = (byte)100;	//Node ID  
			data[4] = (byte)1;
			data[5] = (byte)(Integer.parseInt(parts[2]));//Buzzer enabled
			data[6] = (byte)0;//Motion enabled
			data[7] = (byte)(Integer.parseInt(parts[3]));//Propagate Buzzer enabled
			data[8] = (byte)0;//Buzzer Off
			data[11] = (byte)(Integer.parseInt(parts[1]));//Shut Down
		}
			  
		System.out.println("Sending packet " + counter);
		payload.set_counter(counter);
		
		moteIF.send(0, payload);
		System.out.println(payload);
		counter++;
		try {Thread.sleep(2000);}
		catch (InterruptedException exception) {}
      }
    }
    catch (IOException exception) {
      System.err.println("Exception thrown when sending packets. Exiting.");
      System.err.println(exception);
    }
  }

  public void messageReceived(int to, Message message) {
    TestSerialMsg msg = (TestSerialMsg)message;
    byte[] data = new byte[12];
    data = msg.dataGet();
    System.out.println("Received packet sequence number " + msg.get_counter() + " " + PANid);
    System.out.println("Data rcv from Radio: " + msg + "\n" + Arrays.toString(data) + " .. " + data[3]);
    Client_socket c3 = new Client_socket();
	c3.send_message("BASE NOTIFICATION " + data[3] + " "+ PANid +"\n");
	String answer = c3.receive_message();
	System.out.println("PHP Answer: "+ answer);
    
  }
  
  private static void usage() {
    System.err.println("usage: TestSerial [-comm <source>]");
  }
  
  public static void main(String[] args) throws Exception {
    String source = null;
    if (args.length == 2) {
      if (!args[0].equals("-comm")) {
	usage();
	System.exit(1);
      }
      source = args[1];
    }
    else if (args.length != 0) {
      usage();
      System.exit(1);
    }
    
    PhoenixSource phoenix;
    
    if (source == null) {
      phoenix = BuildSource.makePhoenix(PrintStreamMessenger.err);
    }
    else {
      phoenix = BuildSource.makePhoenix(source, PrintStreamMessenger.err);
    }

    MoteIF mif = new MoteIF(phoenix);
    TestSerial serial = new TestSerial(mif);
    serial.sendPackets();
  }


}
